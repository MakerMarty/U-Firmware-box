import uos
import ujson
import sys
import machine
import io
import uasyncio as asyncio

# Dossier dans lequel on télécharge tous les fichiers Firmware + App
TEMP_UPDATE_DIR = "/temp"
# Fichier pour backup en cas de problème
BACKUP_DIR = "/backup"
# Fichier de config car on remplace tout sauf la configuration wifi
CONFIG_FILE = "config.json"
# Dossier contient l'application
APP_FOLDER = "/app"
# Dossier contient le firmware
FIRMWARE_FOLDER = "/firmware"

RUNNING_APP_PATH = APP_FOLDER
BACKUP_APP_PATH = f"{BACKUP_DIR}{APP_FOLDER}"
UPDATE_APP_PATH = f"{TEMP_UPDATE_DIR}{APP_FOLDER}"
UPDATE_FIRMWARE_PATH = f"{TEMP_UPDATE_DIR}{FIRMWARE_FOLDER}"

# Ajouter le répertoire 'app' au sys.path si ce n'est pas déjà fait
if RUNNING_APP_PATH not in sys.path:
    sys.path.append(RUNNING_APP_PATH)
    print(f"Répertoire {RUNNING_APP_PATH} ajouté au sys.path.")

import config
import ota_manager
import bluetooth_manager
import wifi_manager
import utarfile

def has_files(directory):
    try:
        for item in uos.listdir(directory):
            path = f"{directory}/{item}"
            stat = uos.stat(path)
            if stat[0] & 0x4000:  # C'est un répertoire
                if has_files(path):
                    return True
            else:
                return True
    except Exception as e:
        print(f"[ERR] has_files: {e}")
    return False

def copy_all(src, dst):
    try:
        if not src.endswith("/"):
            src += "/"
        for item in uos.listdir(src):
            src_path = src + item
            dst_path = dst + "/" + item
            print(f"JMA : Source Path = {src_path} --- Dest Path = {dst_path}")
            stat = uos.stat(src_path)
            if stat[0] & 0x4000:  # check if file is type of directory
                if item not in uos.listdir(dst):
                    uos.mkdir(dst_path)
                copy_all(src_path, dst_path)
            else:
                with open(src_path, "rb") as fsrc, open(dst_path, "wb") as fdst:
                    fdst.write(fsrc.read())
    except Exception as e:
        print(f"[ERR] copy_all: {e}")

def delete_all(directory):
    for item in uos.listdir(directory):
        path = f"{directory}/{item}"
        try:
            stat = uos.stat(path)
            if stat[0] & 0x4000:
                delete_all(path)
                uos.rmdir(path)
            else:
                uos.remove(path)
        except Exception as e:
            print(f"[ERR] delete_all: {e}")

def safe_mkdir(path):
    try:
        uos.mkdir(path)
    except:
        pass

def find_tar_file(path):
    for fname in uos.listdir(path):
        if fname.endswith(".tar"):
            return "{}/{}".format(path, fname)
    return None

def join_paths(*paths):
    return '/'.join(path.strip('/') for path in paths)

def extract_tar_file(tar_file_path, destination_path):
    try:
        tar_file = find_tar_file(tar_file_path)
        t = utarfile.TarFile(tar_file)
        for i in t:
            print(f"File: {i.name}")
            if i.name in (".", "./", ""):
                continue  # Ignorer les entrées racine

            # Construire le chemin absolu pour extraction
            full_path = join_paths(destination_path, i.name.lstrip("./"))
            print(f"Extraction: {full_path}")

            if i.type == utarfile.DIRTYPE:
                safe_mkdir(full_path)
            else:
                # Extraire le fichier et l'enregistrer
                f = t.extractfile(i)
                with open(full_path, "wb") as of:
                    of.write(f.read())
                    
        print("✅ Extraction terminée.")
    except Exception as e:
        print(f"[ERR] extract_tar_file file: {tar_file_path} to destination {destination_path}: {e}")
        raise

def start_app():
        uos.chdir('app')
        import app_boot
        if hasattr(app_boot, "start"):
            print("🚀🚀🚀🚀🚀🚀🚀🚀🚀 APP START !!!!!!")
            app_boot.start()
        else:
            print("[ERR] app_boot.start() not found")
            raise Exception("app_boot.start() not found")
        

def create_structure_folders():
    safe_mkdir(TEMP_UPDATE_DIR)
    safe_mkdir(UPDATE_APP_PATH)
    safe_mkdir(UPDATE_FIRMWARE_PATH)
    safe_mkdir(BACKUP_DIR)
    safe_mkdir(BACKUP_APP_PATH)

async def main():
    try:
        print("[BOOT] Démarrage")
        current_firmware_version = uos.uname().release
        print(f"[BOOT] CURRENT VERSION : {current_firmware_version}")

        ############ LOAD CONFIG
        print("[INFO] LOAD CONFIG")
        _config = config.ConfigInfo(f"{APP_FOLDER}/config.json")
        print(f" \
            JMA = app_version = {_config.Firmware.app_version}\n\
            firmware_version = {_config.Firmware.firmware_version}\n\
            url = {_config.Firmware.url}\n\
            version_file = {_config.Firmware.version_file}")
        ############ CREATE FOLDERS FOR UPADATE AND BACKUP
        print("[INFO] CREATE FOLDERS STRUCTURE")
        create_structure_folders()
        
        ############ CONNECT TO INTERNET WITH WIFI AND IF NOT CONFIGURED OPEN BLE
        
        #ssid = _config.Wifi.ssid
        #password = _config.Wifi.password
        connected = False
        while _config.Wifi.ssid == "" or _config.Wifi.password == "" or not connected: #or not wifi_manager.connect_wifi(_config.Wifi.ssid, _config.Wifi.password, _config.Wifi.nb_retry):
            print(f"[INFO] CONNECT TO INTERNET WITH WIFI {_config.Wifi.ssid} - {_config.Wifi.password}")
            if _config.Wifi.ssid and _config.Wifi.password:
                #print(f"Connexion au Wi-Fi {ssid}...")
                if not wifi_manager.connect_wifi(_config.Wifi.ssid, _config.Wifi.password, _config.Wifi.nb_retry):
                    print(f"Impossible de se connecter au Wi-Fi avec les informations fournies: {_config.Wifi.ssid} - {_config.Wifi.password}.")
                    # get new wifi values from BLE
                    new_value = await bluetooth_manager.get_wifi_info_from_ble()
                    print("BOOT : NEW VALUES = ", new_value.wifi_ssid, " - ", new_value.wifi_password)
                    _config.Wifi.ssid = new_value.wifi_ssid
                    _config.Wifi.password = new_value.wifi_password
                    _config.save_config()
                    if not new_value.wifi_ssid or not new_value.wifi_password:
                        print("Aucun moyen de se connecter au Wi-Fi. Vérifie la connexion Bluetooth.")
                        continue
                else:
                    connected = True
            else:
                print("Aucune configuration Wi-Fi trouvée, tentative de configuration Bluetooth.")
                new_value = await bluetooth_manager.get_wifi_info_from_ble()
                print("BOOT : NEW VALUES = ", new_value.wifi_ssid, " - ", new_value.wifi_password)
                _config.Wifi.ssid = new_value.wifi_ssid
                _config.Wifi.password = new_value.wifi_password
                _config.save_config()
                if not new_value.wifi_ssid or not new_value.wifi_password:
                    print("Impossible de configurer Wi-Fi via Bluetooth.")
                    continue
        
        print("✅ Connexion Wi-Fi réussie.")

        ############ GET APP VERSION FROMGIT REPO
        print("[INFO] GET APP VERSION FROMGIT REPO")
        app_version = ota_manager.check_app_for_update(_config.Firmware.url, _config.Firmware.version_file, _config.Firmware.app_version)

        ############ CHECK IF UPDATE OF APP IS NEEDED
        print(f"[INFO] CHECK IF UPDATE OF APP IS NEEDED : app_version={app_version} - _config.Firmware.app_version = {_config.Firmware.app_version}")
        if(app_version != "" and app_version != _config.Firmware.app_version and app_version != _config.Firmware.app_last_update_version):
            print(f"[INFO] app_version != _config.Firmware.app_version : {app_version} != {_config.Firmware.app_version}")
            if has_files(UPDATE_APP_PATH):
                print("[INFO] Mise à jour de l'application détectée")
                update_app(_config, app_version)
            else:
                # DOWNLOAD LATEST VERSION OF APP
                print("[INFO] Download new app firmware ...")
                ota_manager.download_app_firmware(_config.Firmware.url, app_version, _config.Firmware.app_prefix, _config.Firmware.app_extension, UPDATE_APP_PATH)
                print("Reboot en cours...")
                machine.reset() # need to reboot to apply update
                return
        else:
            print("[INFO] Pas de mise à jour d'application")
            import app_boot
            app_boot.start()

    except Exception as e:
        print(f"[ERR] boot failed: {e}")
        #ROLLBACK !!!!
        print("[ERR] Rollback in progress ...")
        try:
            rollback()
            # RESET after rollback
        except Exception as rollback_error:
            print(f"[ERR] rollback failed: {rollback_error}")
            sys.exit(1)


def rollback():
    print("[INFO] Rollback in progress ...")
    print("[INFO] Rollback check if backup folder contains previous app ...")
    
    # BACKUP FOLDER CONTAINS NEW APP FIRMWARE ?
    if has_files(BACKUP_APP_PATH):
        # YES : 
        ## REPLACE /backup/app/config.json app_last_update_version WITH /app/config.json app_last_update_version
        print("[INFO] Rollback : config.json files ...")
        _backup_config = config.ConfigInfo(f"{BACKUP_APP_PATH}/config.json")
        _app_config = config.ConfigInfo(f"{RUNNING_APP_PATH}/config.json")
        print("[INFO] Rollback : update app_last_update_version ...")
        _backup_config.Firmware.app_last_update_version = _app_config.Firmware.app_last_update_version
        _backup_config.save_config()
        ## DELETE /app
        print("[INFO] Rollback : delete /app ...")
        delete_all(RUNNING_APP_PATH)
        ## COPY /backup/app TO /app
        print("[INFO] Rollback : copy /backup/app TO /app ...")
        copy_all(BACKUP_APP_PATH, RUNNING_APP_PATH)
        print("✅ Rollback terminé.")
        ## DELETE /backup/app
        print("[INFO] Rollback : delete /app ...")
        delete_all(BACKUP_APP_PATH)
        ## RESTART
        machine.reset()
    else:
        # NO : EXIT
        print("[ERR] Rollback impossible : No backup exists")
        machine.reset()

def update_app(config_file, app_version):
    try:
        print("[INFO] Mise à jour de l'application en cours ...")

        # Erase /backup/app files and folders
        delete_all(BACKUP_APP_PATH)
        # Copy all files and folders from /app to /backup/app
        copy_all(RUNNING_APP_PATH, BACKUP_APP_PATH)

        # Extract
        print(f"Extraction de l'app en cours ({UPDATE_APP_PATH})")
        # Clear /app to extract new version in running folder fom /temp/app
        delete_all(RUNNING_APP_PATH)
        # Extract /temp/app to /app
        extract_tar_file(UPDATE_APP_PATH, RUNNING_APP_PATH)

        # Update config file
        print("[INFO] Mise à jour de la configuration en cours ...")
        config_file.Firmware.app_version = app_version
        config_file.Firmware.app_last_update_version = app_version
        
        # Copy WiFi information from backup version 
        _temp_config = config.ConfigInfo(f"{BACKUP_APP_PATH}/config.json")
        config_file.Wifi = _temp_config.Wifi
        config_file.save_config()
        print(f"Ancienne configuration : \n{_temp_config.Wifi}")
        print(f"Nouvelle configuration : \n{config_file.Wifi}")
        
        # Delete /temp/app
        delete_all(UPDATE_APP_PATH)

        # Restart app
        print("[OK] MAJ réussie")
        print("Reboot en cours...")
        machine.reset()
    except Exception as e:
        print(f"[ERR] update_app failed: {e}")
        # Suppression de la MAJ et rollback
        delete_all(UPDATE_APP_PATH)
        rollback()

def test():
    import app_boot
    _config = config.ConfigInfo(f"{APP_FOLDER}/config.json")
    app_boot.start(_config)

#asyncio.run(main())
test()