import sys
import machine
import os
import const
import updater

def start_main():
    try:
        # check if update needed
        if updater.need_update_or_rollback():
            #Update the app or rollback
            updater.update_or_rollback()
        else:
            #Run the app
            # Ajouter le répertoire 'app' au sys.path si ce n'est pas déjà fait
            if const.APP_FOLDER_PATH not in sys.path:
                sys.path.append(const.APP_FOLDER_PATH)
                print(f"Répertoire {const.APP_FOLDER_PATH} ajouté au sys.path.")
            print("PAS DE MAJ OU ROLLBACK => LANCE BOOT2")
            import boot2
    except Exception as e:
        print("Erreur au lancement du programme :", repr(e))
        # Activer le flag du rollback
        updater.create_flag("rollback")
        # Reboot
        machine.reset()

#start_main()