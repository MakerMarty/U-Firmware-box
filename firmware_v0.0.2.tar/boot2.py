import uos
import ujson
import sys
import machine
import utarfile
import io

# Dossier dans lequel on télécharge tous les fichiers Firmware + App
TEMP_UPDATE_DIR = "/temp"
# Fichier pour backup en cas de problème
BACKUP_DIR = "/backup"
# Fichier de config car on remplace tout sauf la configuration wifi
CONFIG_FILE = "config.json"
# Dossier contient l'application
APP_FOLDER = "/app"
# Dossier contient le firmware
FIRMWARE_FOLDER = "/firmware"

RUNNING_APP_PATH = APP_FOLDER
BACKUP_APP_PATH = f"{BACKUP_DIR}{APP_FOLDER}"
UPDATE_APP_PATH = f"{TEMP_UPDATE_DIR}{APP_FOLDER}"
UPDATE_FIRMWARE_PATH = f"{TEMP_UPDATE_DIR}{FIRMWARE_FOLDER}"

# Ajouter le répertoire 'app' au sys.path si ce n'est pas déjà fait
if RUNNING_APP_PATH not in sys.path:
    sys.path.append(RUNNING_APP_PATH)
    print(f"Répertoire {RUNNING_APP_PATH} ajouté au sys.path.")

import config
import ota_manager
import bluetooth_manager
import wifi_manager

def has_files(directory):
    try:
        for item in uos.listdir(directory):
            path = f"{directory}/{item}"
            stat = uos.stat(path)
            if stat[0] & 0x4000:  # C'est un répertoire
                if has_files(path):
                    return True
            else:
                return True
    except Exception as e:
        print(f"[ERR] has_files: {e}")
    return False

def copy_all(src, dst, skip_config_wifi=False):
    try:
        if not src.endswith("/"):
            src += "/"
        for item in uos.listdir(src):
            src_path = src + item
            dst_path = dst + "/" + item
            print(f"JMA : Source Path = {src_path} \n Dest Path = {dst_path}")
            stat = uos.stat(src_path)
            if stat[0] & 0x4000:  # check if file is type of directory
                if item not in uos.listdir(dst):
                    uos.mkdir(dst_path)
                copy_all(src_path, dst_path, skip_config_wifi)
            else:
                if skip_config_wifi and item == CONFIG_FILE:
                    merge_config_wifi(src_path, dst_path)
                else:
                    with open(src_path, "rb") as fsrc, open(dst_path, "wb") as fdst:
                        fdst.write(fsrc.read())
    except Exception as e:
        print(f"[ERR] copy_all: {e}")


def merge_config_wifi(current_path, new_path):
    try:
        # Lire l'ancienne configuration avec ujson
        with open(current_path, "r") as f:
            current_config = ujson.load(f)
    except OSError as e:
        print("❌ Erreur lecture ancienne config:", e)
        current_config = {}

    try:
        # Lire la nouvelle configuration (celle qui va remplacer l'ancienne)
        with open(new_path, "r") as f:
            new_config = ujson.load(f)
    except OSError as e:
        print("❌ Erreur lecture nouvelle config:", e)
        return  # On ne fait rien si le fichier de mise à jour est invalide

    # Si "wifi" existe dans l'ancienne config mais pas dans la nouvelle,
    # on garde la section wifi de l'ancienne config
    if "wifi" in current_config and "wifi" not in new_config:
        new_config["wifi"] = current_config["wifi"]

    # Si les deux configurations ont une section "wifi", on garde celle de l'ancienne
    elif "wifi" in current_config and "wifi" in new_config:
        print("ℹ️ Remplacement section wifi du nouveau fichier par celle de l’actuelle")
        new_config["wifi"] = current_config["wifi"]

    # Sauvegarder la nouvelle configuration fusionnée dans le fichier actuel
    try:
        with open(current_path, "w") as f:
            ujson.dump(new_config, f)
            print("✅ Configuration mise à jour avec Wi-Fi conservé.")
    except OSError as e:
        print("❌ Erreur d'écriture de la configuration fusionnée:", e)

def delete_all(directory):
    for item in uos.listdir(directory):
        path = f"{directory}/{item}"
        try:
            stat = uos.stat(path)
            if stat[0] & 0x4000:
                delete_all(path)
                uos.rmdir(path)
            else:
                uos.remove(path)
        except Exception as e:
            print(f"[ERR] delete_all: {e}")

def safe_mkdir(path):
    try:
        uos.mkdir(path)
    except:
        pass

def find_tar_file(path):
    for fname in uos.listdir(path):
        if fname.endswith(".tar"):
            return "{}/{}".format(path, fname)
    return None

def extract_tar_file(tar_file_path, destination_path):
    try:
        tar_file = find_tar_file(tar_file_path)
        t = utarfile.TarFile(tar_file)
        for i in t:
            print(i.name)
            if i.type == utarfile.DIRTYPE:
                uos.mkdir(i.name)
            else:
                f = t.extractfile(i)
                with open(i.name, "wb") as of:
                    of.write(f.read())
        print("✅ Extraction terminée.")
    except Exception as e:
        print(f"[ERR] extract_tar_file: {e}")

def start_app():
        uos.chdir('app')
        import app_boot
        if hasattr(app_boot, "start"):
            print("🚀🚀🚀🚀🚀🚀🚀🚀🚀 APP START !!!!!!")
            app_boot.start()
        else:
            print("[ERR] app_boot.start() not found")
            raise Exception("app_boot.start() not found")
        

def main():
    try:
        print("[BOOT] Démarrage")

        ############ LOAD CONFIG
        _config = config.ConfigInfo("app/config.json")

        ############ CREATE FOLDERS FOR UPADATE AND BACKUP
        safe_mkdir(TEMP_UPDATE_DIR)
        safe_mkdir(UPDATE_APP_PATH)
        safe_mkdir(UPDATE_FIRMWARE_PATH)
        safe_mkdir(BACKUP_DIR)
        safe_mkdir(BACKUP_APP_PATH)

        if has_files(UPDATE_APP_PATH):
            print("[INFO] Mise à jour de l'application détectée")
            #return True
            update_app()
        else:
            print("[INFO] Pas de mise à jour d'application")

        print(f" \
            JMA = app_version = {_config.Firmware.app_version}\n\
            firmware_version = {_config.Firmware.firmware_version}\n\
            url = {_config.Firmware.url}\n\
            version_file = {_config.Firmware.version_file}")
        
        ############ CONNECT TO INTERNET WITH WIFI AND IF NOT CONFIGURED OPEN BLE
        ssid = _config.Wifi.ssid
        password = _config.Wifi.password

        if ssid and password:
            print(f"Connexion au Wi-Fi {ssid}...")
            if not wifi_manager.connect_wifi(ssid, password, _config.Wifi.nb_retry):
                print("Impossible de se connecter au Wi-Fi avec les informations fournies.")
                if not bluetooth_manager.pair_and_connect():
                    print("Aucun moyen de se connecter au Wi-Fi. Vérifie la connexion Bluetooth.")
                    return
        else:
            print("Aucune configuration Wi-Fi trouvée, tentative de configuration Bluetooth.")
            if not bluetooth_manager.pair_and_connect():
                print("Impossible de configurer Wi-Fi via Bluetooth.")
                return
        print("✅ Connexion Wi-Fi réussie.")
        
        ############ CHECK FOR UPDATE BY OTA
        app_version = ota_manager.check_app_for_update(_config.Firmware.url, _config.Firmware.version_file, _config.Firmware.app_version)
        if(app_version != ""):
            ota_manager.download_app_firmware(_config.Firmware.url, app_version, _config.Firmware.app_prefix, _config.Firmware.app_extension, UPDATE_APP_PATH)
            print("Reboot en cours...")
            machine.reset() # need to reboot to apply update
            return
        
        if(ota_manager.check_firmware_for_update(_config.Firmware.url, _config.Firmware.version_file, _config.Firmware.firmware_version)):
            print("[INFO] Mise à jour du firmware détectée")
            #update_firmware()
        else:
            print("[INFO] Pas de mise à jour de firmware")
        import app_boot
        app_boot.start()
    except Exception as e:
        print(f"[ERR] boot failed: {e}")
        #TODO : ROLLBACK !!!!
        print("[ERR] Rollback in progress ...")
        rollback()

def rollback():
    print("[INFO] Rollback in progress ...")
    # delete_all(UPDATE_APP_PATH)
    # copy_all(BACKUP_APP_PATH, RUNNING_APP_PATH)
    # delete_all(BACKUP_APP_PATH)

def update_app():
    print("[INFO] Mise à jour de l'application en cours ...")

    # Backup
    delete_all(BACKUP_APP_PATH)
    copy_all(RUNNING_APP_PATH, BACKUP_APP_PATH, skip_config_wifi=True)

    # Mise à jour
    copy_all(UPDATE_APP_PATH, RUNNING_APP_PATH, skip_config_wifi=True)
    print(f"Extraction de l'app en cours ({UPDATE_APP_PATH})")
    extract_tar_file(UPDATE_APP_PATH, RUNNING_APP_PATH)
    delete_all(UPDATE_APP_PATH)
    print("[OK] MAJ réussie")
    print("Reboot en cours...")
    machine.reset()


    # Test du boot
    # if try_import_and_start():
    #     print("[OK] MAJ réussie")
    #     delete_all(UPDATE_APP_PATH)
    #     delete_all(BACKUP_APP_PATH)
    # else:
    #     print("[ERR] MAJ échouée, rollback")
    #     copy_all(BACKUP_APP_PATH, "/", skip_config_wifi=True)
    #     delete_all(UPDATE_APP_PATH)
    #     delete_all(BACKUP_APP_PATH)
    #     try_import_and_start()

def update_firmware():
    print("[INFO] Mise à jour du firmware en cours ...")
    tempFirmwareFolder = UPDATE_FIRMWARE_PATH
    firmware_file = get_firmware_file(tempFirmwareFolder)
    if firmware_file:
        print(f"[INFO] Firmware trouvé ! Installation de : {firmware_file}")
        import esp32
        import machine
        current = esp32.Partition(esp32.Partition.RUNNING)
        next_ota = current.get_next_update()
        print("[INFO] 📝 Écriture du firmware dans :", next_ota.info()[0])

        firmware_data = load_firmware(firmware_file)  # Charge les données binaires du fichier
        next_ota.write(firmware_data)

        # Delete firmware file
        delete_all(tempFirmwareFolder)

        print("[INFO] 🔁 Bascule vers", next_ota.info()[0])
        next_ota.set_boot()

        print("[INFO] 🚀 Redémarrage sur nouveau firmware...")
        machine.reset()
        #update_firmware(firmware_file)
    else:
        print("[ERR] Aucun fichier .bin trouvé dans le dossier de mise à jour.")

# Fonction pour récupérer le nom du fichier .bin dans le dossier
def get_firmware_file(directory):
    try:
        uos.stat(directory)  # Vérifie si le répertoire existe
        files = uos.listdir(directory)
        # Liste tous les fichiers et cherche un fichier .bin
        for file in files:
            if file.endswith(".bin"):
                return directory + "/" + file  # Retourne le chemin complet du fichier .bin
        return None  # Si aucun fichier .bin n'est trouvé
    except OSError:
        print(f"[ERR] Répertoire non trouvé : {directory}")
        return None

def test():
    update_firmware()

def load_firmware(file_path):
    with open(file_path, "rb") as f:
        return f.read()  # Retourne les données binaires du fichier

main()
#test()