import sys
import machine
import os
import const
import utils
import updater

def start_main():
    try:
        # check if update needed
        if updater.need_update_or_rollback():
            #Update the app or rollback
            updater.update_or_rollback()
        else:
            #Run the app
            # Ajouter le repertoire 'app' au sys.path si ce n'est pas deja fait
            if const.APP_FOLDER_PATH not in sys.path:
                sys.path.append(const.APP_FOLDER_PATH)
                print(f"Repertoire {const.APP_FOLDER_PATH} ajoute au sys.path.")
            print("PAS DE MAJ OU ROLLBACK => LANCE BOOT2")
            import boot2
    except Exception as e:
        print("Erreur au lancement du programme :", repr(e))
        # Activer le flag du rollback
        utils.create_flag(const.FLAGS_ROLLBACK)
        # Reboot
        machine.reset()

start_main()